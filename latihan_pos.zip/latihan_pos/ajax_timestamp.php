<?php
date_default_timezone_set('Asia/Jakarta');//Menyesuaikan waktu dengan tempat kita tinggal
echo $timestamp = date('H:i:s');//Menampilkan Jam Sekarang
?>
 